// models/Job.js

const mongoose = require("mongoose");

const jobSchema = new mongoose.Schema({
  title: { type: String, required: true },
  company: { type: String, required: true },
  location: { type: String, required: true },
  type: { type: String, required: true, enum: ["Full-time", "Internship"] },
  lpa: { type: Number, required: function () { return this.type === "Full-time"; } },
  stipend: { type: Number, required: function () { return this.type === "Internship"; } },
  description: { type: String, required: true },
  aboutCompany: { type: String },
  keySkills: { type: String },
}, { timestamps: true });

module.exports = mongoose.model("Job", jobSchema);
