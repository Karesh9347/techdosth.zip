def two_sum(nums, target):
   #write your code here
print(two_sum([2, 7, 11, 15], 9))