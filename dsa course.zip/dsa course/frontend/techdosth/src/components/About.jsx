import React from "react";
import { Container, Row, Col, Card, ListGroup } from "react-bootstrap";
import Navb from "./Navb";
import Footer from "./Footer";
import '../css/about.css'

const About = () => {
  return (
    <div>
      <Navb />
      <Container className="my-5">
        <Row className="text-center mb-4">
          <Col>
            <h1>Welcome to TechDosth!</h1>
            <p>
              At TechDosth, we are passionate about empowering individuals who
              are eager to master Data Structures and Algorithms (DSA). Our
              platform is dedicated to providing comprehensive resources,
              insightful tutorials, and hands-on practice to help you excel in
              the world of algorithms and coding challenges.
            </p>
          </Col>
        </Row>
        <Row>
          <Col md={6}>
            <Card className="mb-4">
              <Card.Body>
                <Card.Title>Why TechDosth?</Card.Title>
                <ListGroup variant="flush">
                  <ListGroup.Item>
                    <strong>Expertly Curated Content:</strong> Explore a vast
                    library of articles, video tutorials, and coding problems
                    designed by experts to enhance your understanding of key DSA
                    concepts.
                  </ListGroup.Item>
                  <ListGroup.Item>
                    <strong>Interactive Learning:</strong> Engage with interactive
                    coding problems and solutions to test and improve your skills
                    in real-time.
                  </ListGroup.Item>
                  <ListGroup.Item>
                    <strong>Community Support:</strong> Join a vibrant community
                    of like-minded individuals who share your enthusiasm for DSA.
                    Participate in discussions, ask questions, and collaborate on
                    projects.
                  </ListGroup.Item>
                  <ListGroup.Item>
                    <strong>Practical Insights:</strong> Get access to practical
                    tips, industry insights, and best practices that can help you
                    apply your knowledge to real-world scenarios and interviews.
                  </ListGroup.Item>
                </ListGroup>
              </Card.Body>
            </Card>
          </Col>
          <Col md={6}>
            <Card className="mb-4">
              <Card.Body>
                <Card.Title>What we offer?</Card.Title>
                <ListGroup variant="flush">
                  <ListGroup.Item>
                    <strong>In-Depth Tutorials:</strong> Step-by-step guides
                    covering fundamental and advanced topics in DSA.
                  </ListGroup.Item>
                  <ListGroup.Item>
                    <strong>Practice Problems:</strong> A wide range of problems
                    to challenge and refine your problem-solving skills.
                  </ListGroup.Item>
                  <ListGroup.Item>
                    <strong>Video Content:</strong> Engaging video tutorials that
                    break down complex topics into easy-to-understand lessons.
                  </ListGroup.Item>
                  <ListGroup.Item>
                    <strong>Regular Updates:</strong> Stay up-to-date with the
                    latest trends and techniques in the field of DSA.
                  </ListGroup.Item>
                </ListGroup>
              </Card.Body>
            </Card>
          </Col>
        </Row>
        <Row className="text-center mt-4">
          <Col>
            <p>
              Whether you're a beginner looking to build a solid foundation or
              an experienced coder aiming to sharpen your skills, TechDosth is
              here to support your journey. Join us today and take your DSA
              skills to the next level!
            </p>
          </Col>
        </Row>
      </Container>
      <Footer />
    </div>
  );
};

export default About;
