
  import React, { useState,useEffect } from "react";
  import Footer from "./Footer";
  import Navb from "./Navb";
  import "../css/jobs.css";
  import { Button, Card, Container } from "react-bootstrap";
  import { Link } from "react-router-dom";
  import axios from 'axios'
  const Jobs = () => {
    const [searchQuery, setSearchQuery] = useState("");
    const [jobTypeFilter, setJobTypeFilter] = useState([]);
    const [locationFilter, setLocationFilter] = useState([]);
    
    /*const jobs = [
      {
        id: 1,
        title: "Software Engineer",
        company: "Tech Solutions Inc.",
        location: "New York, NY",
        type: "Full-time",
        description:
          "Develop and maintain web applications using modern frameworks.",
        lpa: 15,
      },
      {
        id: 2,
        title: "Marketing Intern",
        company: "Creative Minds",
        location: "Remote",
        type: "Internship",
        description: "Assist in social media marketing and content creation.",
        stipend: 15000,
      },
      {
        id: 3,
        title: "Data Analyst",
        company: "Data Insights",
        location: "San Francisco, CA",
        type: "Full-time",
        description:
          "Analyze and interpret complex data to help drive business decisions.",
        lpa: 12,
      },
      {
        id: 4,
        title: "Graphic Design Intern",
        company: "Design Hub",
        location: "Los Angeles, CA",
        type: "Internship",
        description:
          "Support the design team in creating digital and print media.",
        stipend: 10000,
      },
      {
        id: 5,
        title: "Product Manager",
        company: "Innovate LLC",
        location: "Austin, TX",
        type: "Full-time",
        description: "Oversee product development from concept to launch.",
        lpa: 18,
      },
      {
        id: 6,
        title: "Web Development Intern",
        company: "WebWorks",
        location: "Chicago, IL",
        type: "Internship",
        description: "Assist in developing and testing web applications.",
        stipend: 12000,
      },
      {
        id: 7,
        title: "Sales Associate",
        company: "Retail Partners",
        location: "Boston, MA",
        type: "Full-time",
        description:
          "Engage with customers and drive sales in a fast-paced retail environment.",
        lpa: 8,
      },
      {
        id: 8,
        title: "Content Writing Intern",
        company: "Write & Co.",
        location: "Remote",
        type: "Internship",
        description:
          "Create engaging content for blogs, social media, and websites.",
        stipend: 8000,
      },
    ];*/
    const [jobs, setJobs] = useState([]);  // State to store job listings

    // Fetch jobs from backend
    const getJobs = async () => {
      try {
        const response = await axios.get("http://localhost:5000/get-jobs");
        setJobs(response.data);
       
      } catch (error) {
        console.error("Error fetching jobs:", error);
      }
    };
  
    useEffect(() => {
      getJobs(); 
    }, []);
  
    const alphabetColors = {
      A: "#FF5733",
      B: "#33FF57",
      C: "#3357FF",
      D: "#FF33A6",
      E: "#FF8C33",
      F: "#8C33FF",
      G: "#33FFD1",
      H: "#D1FF33",
      I: "#FF3333",
      J: "#33FF8C",
      K: "#A633FF",
      L: "#33A6FF",
      M: "#FF3380",
      N: "#80FF33",
      O: "#3380FF",
      P: "#FF7033",
      Q: "#FF33D1",
      R: "#70FF33",
      S: "#FF5733",
      T: "#33FFA6",
      U: "#33A6FF",
      V: "#FF33C0",
      W: "#C0FF33",
      X: "#33C0FF",
      Y: "#FF3380",
      Z: "#80FF33",
    };
  
    localStorage.setItem("jobs", JSON.stringify(jobs));
  
    const getCompanyLogo = (name) => {
      const initials = name
        .split(" ")
        .slice(0, 3)
        .map((word) => word[0])
        .join("");
      return initials;
    };
  
    const locations = [
      "Hyderabad",
      "Bangalore",
      "Pune",
      "Mumbai",
      "Chennai",
      "Noida",
      "Indore",
      "Kolkata",
    ];
  
  
  
    const handleJobTypeChange = (event) => {
      const value = event.target.value;
      setJobTypeFilter((prev) =>
        prev.includes(value)
          ? prev.filter((type) => type !== value)
          : [...prev, value]
      );
    };
  
    const handleLocationChange = (event) => {
      const value = event.target.value;
      setLocationFilter((prev) =>
        prev.includes(value)
          ? prev.filter((location) => location !== value)
          : [...prev, value]
      );
    };
  
    const filteredJobs = jobs.filter((job) => {
      const matchesSearch =
        job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        job.company.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesJobType =
        jobTypeFilter.length === 0 || jobTypeFilter.includes(job.type.toLowerCase());
      const matchesLocation =
        locationFilter.length === 0 || locationFilter.includes(job.location);
      return matchesSearch && matchesJobType && matchesLocation;
    });
  
    return (
      <div>
        <Navb />
        <div className="search-container">
          <div className="search">
            <input
              className="search-bar"
              type="text"
              placeholder="Search your dream job and apply now..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <Button className="search-btn">Search</Button>
          </div>
        </div>
        <Container className="jobs-layout">
          <div className="filter-container">
            <h2>Filters</h2>
            <div>
              <h3>Job Type</h3>
              <div>
                <input
                  type="checkbox"
                  id="fulltime"
                  name="jobType"
                  value="full-time"
                  onChange={handleJobTypeChange}
                />
                <label htmlFor="fulltime"> Full-Time</label>
              </div>
              <div>
                <input
                  type="checkbox"
                  id="internship"
                  name="jobType"
                  value="internship"
                  onChange={handleJobTypeChange}
                />
                <label htmlFor="internship"> Internship</label>
              </div>
            </div>
            <div>
              <h3>Location</h3>
              {locations.map((location, index) => (
                <div key={index}>
                  <input
                    type="checkbox"
                    id={location}
                    name="location"
                    value={location}
                    onChange={handleLocationChange}
                  />
                  <label htmlFor={location}>{location}</label>
                </div>
              ))}
            </div>
          </div>
          <div className="jobs-container">
            {filteredJobs.map((job) => (
              <div key={job.id} className="job">
                <div>
                  <div className="company">
                    <div
                      className="company-log"
                      style={{
                        backgroundColor:
                          alphabetColors[getCompanyLogo(job.company)[0]] || "#ccc",
                      }}
                    >
                      {getCompanyLogo(job.company)}
                    </div>
                  </div>
                </div>
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  <div>
                    <h3>{job.title}</h3>
                    <div>
                      <span className="attribute">Company: </span> {job.company}
                    </div>
                  </div>
                  <div>
                    <Button
                      as={Link}
                      to={`/jobs-and-internships-and-hackathons/${job._id}`}
                      style={{
                        marginRight: "30px",
                        padding: "10px",
                        width: "100px",
                      }}
                    >
                      Apply
                    </Button>
                  </div>
                </div>
                <div className="job-details">
                  <div>
                    <span className="attribute">Location: </span> {job.location}
                  </div>
                  <div>
                    <span className="attribute">Job Type: </span> {job.type}
                  </div>
                  <div>
                    <span className="attribute">Salary: </span>{" "}
                    {job.lpa ? `${job.lpa} LPA` : `₹${job.stipend} stipend`}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Container>
        <Footer />
      </div>
    );
  };
  
  export default Jobs;
  