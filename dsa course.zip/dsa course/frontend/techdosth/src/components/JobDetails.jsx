import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import "../css/jobDetails.css";
import Navb from "./Navb";
import Footer from "./Footer";
import { Button } from "react-bootstrap";
import axios from "axios";

const JobDetails = () => {
  const { id } = useParams(); // Get job ID from the URL
  const [job, setJob] = useState(null);
  const [error, setError] = useState(null);
  const [jobs, setJobs] = useState([]);  

  // Fetch job details from the backend
  useEffect(() => {
    const fetchJobDetails = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/job/${id}`);
        setJob(response.data);
      } catch (err) {
        setError("Job not found");
        console.error(err);
      }
    };

    fetchJobDetails();
  }, [id]);

  // Fetch jobs from backend for related jobs
  const getJobs = async () => {
    try {
      const response = await axios.get("http://localhost:5000/get-jobs");
      setJobs(response.data);
    } catch (error) {
      console.error("Error fetching jobs:", error);
    }
  };

  useEffect(() => {
    getJobs(); 
  }, []);

  const filtered_jobs = jobs.filter(
    (item) => item.title.toLowerCase() === job?.title.toLowerCase()
  );

  // Check if the job is found or error
  if (error) return <div>{error}</div>;
  if (!job) return <div>Loading...</div>;

  const getCompanyLogo = (name) => {
    const initials = name
      .split(" ")
      .slice(0, 3)
      .map((word) => word[0])
      .join("");
    return initials;
  };

  const alphabetColors = {
    A: "#FF5733", B: "#33FF57", C: "#3357FF", D: "#FF33A6", E: "#FF8C33", F: "#8C33FF",
    G: "#33FFD1", H: "#D1FF33", I: "#FF3333", J: "#33FF8C", K: "#A633FF", L: "#33A6FF",
    M: "#FF3380", N: "#80FF33", O: "#3380FF", P: "#FF7033", Q: "#FF33D1", R: "#70FF33",
    S: "#FF5733", T: "#33FFA6", U: "#33A6FF", V: "#FF33C0", W: "#C0FF33", X: "#33C0FF",
    Y: "#FF3380", Z: "#80FF33",
  };

  return (
    <div>
      <Navb />
      <div id="job-bag">
        <div id="job">
          <div className="company-info">
            <div>
              <img src="/company.png" alt="Company building" className="company-building" />
            </div>
            <div style={{ marginTop: "20px" }} className="job-info">
              <h1 className="job-title">{job.title}</h1>
              <p className="job-company"><strong>Company:</strong> {job.company}</p>
              <p className="job-location"><strong>Location:</strong> {job.location}</p>
              <p className="job-type"><strong>Type:</strong> {job.type}</p>
              <p className="job-salary"><strong>Salary/Stipend:</strong> {job.lpa ? `${job.lpa} LPA` : `₹${job.stipend}`}</p>
            </div>
          </div>

          <div className="job-details-card">
            <div className="job-navbar">
              <a href="#description" className={window.location.hash === "#description" ? "active" : ""}>Description</a>
              <a href="#about-company" className={window.location.hash === "#about-company" ? "active" : ""}>About Company</a>
              <a href="#key-skills" className={window.location.hash === "#key-skills" ? "active" : ""}>Key Skills</a>
            </div>

            <section id="description" className="job-section">
              <h2>Description</h2>
              <p>{job.description}</p>
            </section>

            <section id="about-company" className="job-section">
              <h2>About Company</h2>
              <p>{job.aboutCompany || "No information provided."}</p>
            </section>

            <section id="key-skills" className="job-section">
              <h2>Key Skills</h2>
              <p>{job.keySkills || "No key skills listed."}</p>
            </section>
          </div>
        </div>

        <div className="related-jobs">
          <h2>Related Jobs</h2>
          {filtered_jobs.map((filteredJob) => (
            <div key={filteredJob.id} className="job">
              <div className="company">
                <div
                  className="company-log"
                  style={{
                    backgroundColor:
                      alphabetColors[getCompanyLogo(filteredJob.company)[0]] || "#ccc",
                  }}
                >
                  {getCompanyLogo(filteredJob.company)}
                </div>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <div>
                  <h3>{filteredJob.title}</h3>
                  <div>
                    <span className="attribute">Company: </span> {filteredJob.company}
                  </div>
                </div>
                <div>
                  <Button
                    as={Link}
                    to={`/jobs-and-internships-and-hackathons/${filteredJob._id}`}
                    style={{
                      marginRight: "30px",
                      padding: "10px",
                      width: "100px",
                    }}
                  >
                    Apply
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default JobDetails;
