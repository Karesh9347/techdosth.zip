import React from 'react'

const ConceptOfTheDay = () => {
  return (
    <div>ConceptOfTheDay</div>
  )
}

export default ConceptOfTheDay