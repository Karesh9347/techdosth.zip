import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import Navb from './Navb';
import Footer from './Footer';
import { Container, Spinner } from 'react-bootstrap';
import '../css/solution.css'
const Solution = () => {
  const { id } = useParams();
  const [question, setQuestion] = useState(null);


  useEffect(() => {
    const fetchQuestion = async () => {
      try {
        const response = await axios.get(`https://techdosth-backend.onrender.com/aquestions/${id}`);
        setQuestion(response.data);
       
      } catch (err) {
        console.log(err);
      }
    };
    fetchQuestion();
  }, [id]);
  function formateDescription(des){
    const l=des.length
    var para=""
    let arr=[]
    for(var i=0;i<l;i++){
      if(des[i]==="*" && para.length>=30){
        arr.push(para)
        para=""
       
        
      }else{
        para+=des.charAt(i)
      }
    }
    arr.push(para)
   
    return (
      <div>
        {arr.map((item, index) => (
          <p key={index}>{item}</p>
        ))}
      </div>
    );
   
  }
  useEffect(() => {
   
    // Adding second ad script dynamically
    const containerAd = document.getElementById("container-f2c1ca9ffe46af45e4160982710441a9");
    if (containerAd) {
      const secondAdScript = document.createElement("script");
      secondAdScript.async = true;
      secondAdScript.setAttribute("data-cfasync", "false");
      secondAdScript.src = "//pl24572181.cpmrevenuegate.com/f2c1ca9ffe46af45e4160982710441a9/invoke.js";
      containerAd.appendChild(secondAdScript);
    }
  }, []);
  
  
  return (
    <div>
      <Navb/>
      {question ? (
        <Container>
          <strong className='head'>Question:</strong>
        <br/>
          <strong style={{color:"red"}}>{question.questionName}</strong>
          <br />
          <strong className='head'>Description:</strong>
        
          <h6 style={{color:"black"}}> {formateDescription(question.description)}</h6>
       
         <div style={{width:"100%",height:"100%"}}>
          <strong>Solutions:</strong>
        <hr/>
         <img src={question.solution} alt='solution' style={{width:"90%",height:"90%"}}/>
         </div>
        </Container>
      ) : (
       <div>
         <Spinner/><small>loading</small>
        </div>
      )}
       <div id="container-f2c1ca9ffe46af45e4160982710441a9" className="text-center mt-4"></div>
      <Footer/>
    </div>
  );
};

export default Solution;
