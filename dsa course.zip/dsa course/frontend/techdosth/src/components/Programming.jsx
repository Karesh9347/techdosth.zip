import React, { useEffect, useState } from 'react';
import { Container, Row, Col, Card } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Link } from 'react-router-dom';
import axios from 'axios';
import Navb from './Navb';
import Footer from './Footer';
import QuestionsList from './QuestionsList';
import '../css/program.css'; // Ensure your CSS file is imported

const program = [
  { id: 1, title: 'Top 100 Interview Questions', image: '/top100.jpeg', description: 'Comprehensive list of the top 100 interview questions across various topics.', url: '/top100' },
  { id: 2, title: 'Arrays', image: '/array.webp', description: 'Key algorithms essential for technical interviews and coding assessments.', url: '/arrays' },
  { id: 3, title: 'Searching Algorithms', image: '/search.png', description: 'Common searching algorithms and their use cases.', url: '/searching' },
  { id: 4, title: 'Sorting Algorithms', image: '/sorting.webp', description: 'Different sorting algorithms and their applications.', url: '/sorting' },
  { id: 5, title: 'Greedy Algorithms', image: '/greedy.png', description: 'Dynamic programming problems and solutions for coding interviews.', url: '/greedy' },
  { id: 6, title: 'Hashmap and Hashset', image: '/hashing.webp', description: 'Graph-related questions and problems for technical interviews.', url: '/hashing' },
  { id: 7, title: 'Two Pointer Algorithms', image: '/twopointer.jpeg', description: 'Dynamic programming problems and solutions for coding interviews.', url: '/two-pointer' },
  { id: 8, title: 'Sliding Window Algorithms', image: '/sliding.webp', description: 'Graph-related questions and problems for technical interviews.', url: '/sliding-window' },
  { id: 9, title: 'Linked List', image: '/linked-list.webp', description: 'System design interview questions and concepts.', url: '/linked-list' },
  { id: 10, title: 'Stack and Queue', image: '/stack.png', description: 'Questions related to database management and SQL.', url: '/stack-and-queues' },
  { id: 11, title: 'Tree Algos and Problems', image: '/trees.webp', description: 'Concurrency issues and solutions in programming.', url: '/trees' },
  { id: 12, title: 'Dynamic Programming', image: '/dp.webp', description: 'Dynamic programming problems and solutions for coding interviews.', url: '/dp' },
  { id: 13, title: 'Graph Theory and Algo', image: '/graph.webp', description: 'Graph-related questions and problems for technical interviews.', url: '/graph' },
  { id: 14, title: 'Recursion Theory and Algo', image: '/recursion.png', description: 'Recursion-related questions and problems for technical interviews.', url: '/recursion' },
];

const Programming= () => {
  
  return (
    <div>
      <Navb />
      <Container fluid className="px-3" id='img-div1'>
        <div className="horizontal-scroll">
          <Row className="gx-4">
            {program.map((question) => (
              <Col xs={6} sm={4} md={3} lg={2} key={question.id} className="mb-4">
                <Link to={question.url} style={{ textDecoration: 'none' }}>
                  <Card className="h-100 hover-card">
                    <Card.Img variant="top" src={question.image} className="card-img-top" />
                    <Card.Body className="d-flex flex-column" style={{ backgroundColor: "#E6E6FA" }}>
                      <Card.Title className="mt-2">{question.title}</Card.Title>
                      <Card.Text className="flex-grow-1" style={{ textDecoration: "none", color: "inherit" }}>
                        {question.description}
                      </Card.Text>
                    </Card.Body>
                  </Card>
                </Link>
              </Col>
            ))}
          </Row>
        </div>
      </Container>
      <QuestionsList searchItems="none" />
      <Footer />
    </div>
  );
};

export default Programming;
