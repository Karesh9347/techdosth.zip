import React, { useState } from "react";
import axios from "axios";
import { Container, Row, Col, Form, Button, Alert } from "react-bootstrap";

const AddApt= () => {
    const [formData, setFormData] = useState({
        questionName: "",
        difficultyLevel: "",
        description: "",
    });

    const [solution, setSolution] = useState(""); // To store the Base64 string of the selected image
    const [message, setMessage] = useState("");
    const [messageType, setMessageType] = useState("success"); // To handle message type

    // Handle form input changes
    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value
        });
    };

    // Handle image file selection
    const handleImageChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setSolution(reader.result); // Store the Base64 string
                console.log(reader.result);
            };
            reader.readAsDataURL(file);
        }
    };

    // Handle form submission
    const handleSubmit = async (e) => {
        e.preventDefault();

        const { questionName, difficultyLevel, description } = formData;

        // Validation check for required fields
        if (!questionName || !difficultyLevel || !description || !solution) {
            setMessage("All fields are required, including the image.");
            setMessageType("danger");
            return;
        }

        try {
            // Include the Base64 image string in the form data
            const dataToSend = { 
                questionName, 
                difficultyLevel, 
                description, 
                solution 
            };

            // Axios POST request to add aptitude question
            const response = await axios.post("https://techdosth-backend.onrender.com/add-aptitude", dataToSend);

            // Handle success response
            if (response.status === 201) {
                setMessage("Aptitude question added successfully!");
                setMessageType("success");
                setFormData({
                    questionName: "",
                    difficultyLevel: "",
                    description: "",
                });
                setSolution(""); // Reset image
            }
        } catch (error) {
            // Handle error response
            setMessage(`Error: ${error.response?.data?.error || "Unable to add question."}`);
            setMessageType("danger");
        }
    };

    return (
        <Container>
            <h2 className="mt-4">Add Aptitude Question</h2>
            <Form onSubmit={handleSubmit}>
                <Form.Group controlId="formQuestionName">
                    <Form.Label>Question Name:</Form.Label>
                    <Form.Control
                        type="text"
                        name="questionName"
                        value={formData.questionName}
                        onChange={handleChange}
                        placeholder="Enter question name"
                    />
                </Form.Group>

                <Form.Group controlId="formDifficultyLevel">
                    <Form.Label>Difficulty Level:</Form.Label>
                    <Form.Control
                        as="select"
                        name="difficultyLevel"
                        value={formData.difficultyLevel}
                        onChange={handleChange}
                    >
                        <option value="">Select difficulty</option>
                        <option value="Easy">Easy</option>
                        <option value="Medium">Medium</option>
                        <option value="Hard">Hard</option>
                    </Form.Control>
                </Form.Group>

                <Form.Group controlId="formDescription">
                    <Form.Label>Description:</Form.Label>
                    <Form.Control
                        as="textarea"
                        name="description"
                        value={formData.description}
                        onChange={handleChange}
                        placeholder="Enter description"
                    />
                </Form.Group>

                <Form.Group controlId="formImageUpload">
                    <Form.Label>Upload Image:</Form.Label>
                    <Form.File
                        accept="image/*"
                        onChange={handleImageChange}
                    />
                </Form.Group>

                <Button variant="primary" type="submit" className="mt-3">
                    Add Question
                </Button>
            </Form>

            {/* Display success/error message */}
            {message && (
                <Alert variant={messageType} className="mt-3">
                    {message}
                </Alert>
            )}
        </Container>
    );
};

export default AddApt;
