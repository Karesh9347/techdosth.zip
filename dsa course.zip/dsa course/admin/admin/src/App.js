
import './App.css';

import Urls from './Urls';

function App() {
  return (
    <div className="App">
    <Urls/>
    </div>
  );
}

export default App;
