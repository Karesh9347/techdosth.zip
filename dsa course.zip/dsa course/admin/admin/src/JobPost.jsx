import React, { useState } from "react";
import { Button, Form } from "react-bootstrap";
import AdminSidebar from "./AdminSidebar";
import axios from "axios";  // Import axios if using it

const JobPost = ({ show, handleClose }) => {
  const [jobDetails, setJobDetails] = useState({
    title: "",
    company: "",
    location: "",
    type: "",
    lpa: "",
    stipend: "",
    description: "",
    aboutCompany: "",
    keySkills: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setJobDetails({ ...jobDetails, [name]: value });
  };

  const handleSubmit = async () => {
    try {
      // Make a POST request to send data to the backend
      await axios.post("http://localhost:5000/add-jobs", jobDetails);
      alert("Job posted successfully!");
      setJobDetails({
        title: "",
        company: "",
        location: "",
        type: "",
        lpa: "",
        stipend: "",
        description: "",
        aboutCompany: "",
        keySkills: "",
      });
      handleClose(); // Close the modal if needed
    } catch (error) {
      console.error("Failed to post job", error);
      alert("Failed to post job");
    }
  };

  return (
    <div className="job-form">
      <AdminSidebar />
      <div className="form-container">
        <Form>
          <Form.Group controlId="title">
            <Form.Label>Job Title</Form.Label>
            <Form.Control
              type="text"
              name="title"
              value={jobDetails.title}
              onChange={handleChange}
            />
          </Form.Group>

          <Form.Group controlId="company">
            <Form.Label>Company Name</Form.Label>
            <Form.Control
              type="text"
              name="company"
              value={jobDetails.company}
              onChange={handleChange}
            />
          </Form.Group>

          <Form.Group controlId="location">
            <Form.Label>Location</Form.Label>
            <Form.Control
              type="text"
              name="location"
              value={jobDetails.location}
              onChange={handleChange}
            />
          </Form.Group>

          <Form.Group controlId="type">
            <Form.Label>Job Type</Form.Label>
            <Form.Control
              as="select"
              name="type"
              value={jobDetails.type}
              onChange={handleChange}
            >
              <option value="">Select</option>
              <option value="Full-time">Full-time</option>
              <option value="Internship">Internship</option>
            </Form.Control>
          </Form.Group>

          <Form.Group controlId="lpa">
            <Form.Label>Salary (LPA)</Form.Label>
            <Form.Control
              type="number"
              name="lpa"
              value={jobDetails.lpa}
              onChange={handleChange}
              disabled={jobDetails.type === "Internship"}
            />
          </Form.Group>

          <Form.Group controlId="stipend">
            <Form.Label>Stipend (₹)</Form.Label>
            <Form.Control
              type="number"
              name="stipend"
              value={jobDetails.stipend}
              onChange={handleChange}
              disabled={jobDetails.type === "Full-time"}
            />
          </Form.Group>

          <Form.Group controlId="description">
            <Form.Label>Description</Form.Label>
            <Form.Control
              as="textarea"
              rows={3}
              name="description"
              value={jobDetails.description}
              onChange={handleChange}
            />
          </Form.Group>

          <Form.Group controlId="aboutCompany">
            <Form.Label>About Company</Form.Label>
            <Form.Control
              as="textarea"
              rows={3}
              name="aboutCompany"
              value={jobDetails.aboutCompany}
              onChange={handleChange}
            />
          </Form.Group>

          <Form.Group controlId="keySkills">
            <Form.Label>Key Skills</Form.Label>
            <Form.Control
              as="textarea"
              rows={2}
              name="keySkills"
              value={jobDetails.keySkills}
              onChange={handleChange}
            />
          </Form.Group>

          <Button variant="primary" onClick={handleSubmit}>
            Save
          </Button>
        </Form>
      </div>
    </div>
  );
};

export default JobPost;
