import React from 'react'

const Resume = () => {
  return (
    <div>
        <iframe typeof='file' src='/job-resume.pdf' width="100%"style={{height:'700px'}} title='resume'/>
       
    </div>
  )
}

export default Resume