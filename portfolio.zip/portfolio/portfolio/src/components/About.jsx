import React, { useState } from "react";
import "../styles/about.css";
import Header from "./Header";
import { Col, Container, Row } from "react-bootstrap";

const About = () => {
  return (
    <div className="home">
      <Header />
      <center>
        <Container style={{ marginTop: -40 }}>
          <Row>
            <Col md={6} id="about-content">
              <h2>About Me</h2>
              <div>
                Hello there! I'm Naresh, a passionate full-stack developer and
                Python engineer with a knack for crafting elegant solutions to
                complex problems. With 1+ of experience in the tech industry, I
                thrive on turning ideas into reality through code.
                <br />
                <h2 style={{ color: "blueviolet" }}>Technical Expertise</h2>
                As a full-stack developer, I specialize in building robust web
                applications from front to back. My proficiency spans across the
                following technologies:
                <br />
                <h3>Frontend Development:</h3> HTML5, CSS3, JavaScript (ES6+),
                React.js,
                <h3>Backend Development:</h3> Python ( Django), Node.js,
                Express.js
                <br />
                <h3>Database Management:</h3> SQL (MySQL), NoSQL (MongoDB)
                <br />
              </div>
            </Col>
            <br />
            <br />
            <br />
            <Col md={6} style={{marginTop:30}}>
              <img
                src="/new.png"
                alt=""
                width="110%"
                height="110%"
                className="image-of"
              />
            </Col>
          </Row>
        </Container>
      </center>
    </div>
  );
};

export default About;
