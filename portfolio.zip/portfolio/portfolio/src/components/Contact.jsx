/*import React, { useState } from 'react';

import Header from './Header';
import '../styles/contact.css'
const Contact = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [formSubmitted, setFormSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault(); 
   

    setFormSubmitted(true);

  
    setName('');
    setEmail('');
    setMessage('');
  };

  return (
    <div className='home'>
      <Header/>
  
    <section className="contact-page">
      <header>
        <h1>Contact</h1>
      </header>
      <main>
        <section className="contact-form">
          <h2>Get in touch</h2>
          {formSubmitted ? (
            <p className="success-message">Thank you for your message! I'll get back to you soon.</p>
          ) : (
            <form onSubmit={handleSubmit}>
              <label htmlFor="name">Name:</label>
              <input
                type="text"
                id="name"
                name="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
              <label htmlFor="email">Email:</label>
              <input
                type="email"
                id="email"
                name="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
              <label htmlFor="message">Message:</label>
              <textarea
                id="message"
                name="message"
                rows="5"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                required
              ></textarea>
              <button type="submit">Send Message</button>
            </form>
          )}
        </section>
        <section className="contact-info">
          <h2>Alternatively, reach out here:</h2>
          <ul>
            <li>
              <a href="mailto:youremail@example.com">nareshpattapu686@gmail.com</a>
        </li>
          </ul>
        </section>
      </main>
    
    </section>
    </div>
  );
};

export default Contact;
*/
import React, { useState } from 'react';
import { Container, Form, Button } from 'react-bootstrap';
import Header from './Header';
const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });

  const handleChange = e => {
    const { name, value } = e.target;
    setFormData(prevState => ({
      ...prevState,
      [name]: value
    }));
  };

  const handleSubmit = e => {
    e.preventDefault();
    console.log(formData);
    setFormData({
      name: '',
      email: '',
      message: ''
    });
  };

  return (
    <div className="contact-page" style={{ backgroundColor: 'black', color: 'white', minHeight: '100vh' }}>
      <Header/>
      <Container>
        <h2>Contact Me</h2>
        <Form onSubmit={handleSubmit}>
          <Form.Group controlId="name">
            <Form.Label>Name:</Form.Label>
            <Form.Control
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              required
            />
          </Form.Group>
          <Form.Group controlId="email">
            <Form.Label>Email:</Form.Label>
            <Form.Control
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              required
            />
          </Form.Group>
          <Form.Group controlId="message">
            <Form.Label>Message:</Form.Label>
            <Form.Control
              as="textarea"
              rows={3}
              name="message"
              value={formData.message}
              onChange={handleChange}
              required
            />
          </Form.Group>
          <br/>
          <Button variant="primary" type="submit">
            Submit
          </Button>
        </Form>
      </Container>
    </div>
  );
};

export default ContactPage;
