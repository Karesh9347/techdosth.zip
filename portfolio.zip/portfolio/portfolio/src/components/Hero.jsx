import React from "react";
import {
  Button,
  Row,
  Col,
  Card,
  CardTitle,
  CardHeader,
  CardBody,
} from "react-bootstrap";
import "../styles/Hero.css";
import {
  Facebook,
  Github,
  Instagram,
  Linkedin,
  Twitter,
  Whatsapp,
} from "react-bootstrap-icons";
import { Link } from "react-router-dom";

import "../styles/about.css";
const Hero = () => {
  return (
    <div className="container1">
      <Row>
        <Col md={6}>
          <img src="/naresh37.png" alt="" id="hero" />
        </Col>
        <Col md={6}>
          <div className="content">
            <h2>
              <span className="text-danger">P</span>attapu{" "}
              <span className="text-danger">N</span>aresh
            </h2>

            <h3>web developer & AI engineer</h3>
            <p>
              A passionate developer with expertise in web, app development, and
              AI.
            </p>
            <Button variant="primary">
              <Link style={{ textDecoration: "none", color: "white" }} id="po" to="/projects">
                projects
              </Link>
            </Button>
            <Button variant="outline-primary">
              <Link to="/resume" style={{ textDecoration: "none" }}>
                resume
              </Link>
            </Button>
            <br />
            <br />
            <div>
            <a href="https://www.instagram.com/shopping_wall98?igsh=MTQ3MXlxZHg5dDRv"><Instagram
                size={30}
                className=" text-danger mx-2"
                id="icon-1"
                title="instagram"
              ></Instagram></a>
              <a href="https://www.facebook.com/pattapu.naresh?mibextid=ZbWKwL"><Facebook
                size={30}
                className=" text-primary  mx-2"
                id="icon-1"
                title="facebook"
              ></Facebook></a>
              <a href="https://github.com/Karesh9347"><Github
                size={30}
                className=" text-secondary  mx-2"
                id="icon-1"
                title="github"></Github></a>
              <Whatsapp
                size={30}
                className=" text-success  mx-2"
                bg="success"
                id="icon-1"
                title="whatsApp"
              />
              <Twitter
                size={30}
                className=" text-primary  mx-2"
                id="icon-1"
                title="twitter"
              />
              <a href="https://www.linkedin.com/in/pattapu-naresh-63b49b2a2?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app"><Linkedin
                size={30}
                className=" text-primary  mx-2"
                id="icon-1"
                title="linkedin"
              ></Linkedin></a>
            </div>
          </div>
        </Col>
      </Row>
      <br></br>
      <Row  className="g-2">
        <h2 className="edu-head">Education</h2>
        <Col className="education" md={4}>
          <Card className="study">
            <CardHeader>
              <CardTitle>10th Grade:</CardTitle>
            </CardHeader>
            <CardBody>
              <p>School Name: KSN ZPPHS HIGH SCHOOL,SURVEPALLI </p>
              <p>Year of Passing: 2018-2019</p>
              <p>Percentage: 9.0 GPA</p>
            </CardBody>
          </Card>
          </Col>
          <Col className="education" md={4}>
          <Card className="study">
            <CardHeader>
              <CardTitle>intermedaite:</CardTitle>
            </CardHeader>
            <CardBody>
              <p> college Name: sri chaithanya junior college,dhanalaksmi puram </p>
              <p>Year of Passing: 2019-2021</p>
              <p>Percentage: 909 MARKS</p>
            </CardBody>
          </Card>
          </Col>
          <Col className="education" md={4}>
          <Card className="study">
            <CardHeader>
              <CardTitle>B.TECH</CardTitle>
            </CardHeader>
            <CardBody>
              <p> college Name: PBR visvodaya engineering college </p>
              <p>Year of Passing: 2021-2025</p>
              <p>Percentage: 82.00 CGPA</p>
            </CardBody>
          </Card>
        </Col>
      </Row>
    </div>
  );
};

export default Hero;
