import React from 'react'
import Header from './Header'
import Hero from './Hero'
import '../styles/Hero.css'
const Home = () => {
  return (
    <div className='home'>
        <Header/>
        <Hero/>
    </div>
  )
}

export default Home