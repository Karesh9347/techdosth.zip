import React from "react";
import Header from "./Header";
import { Container, Row, Col } from "react-bootstrap";
import "../styles/Projects.css";
const Projects = () => {
  return (
    <div className="home">
      <Header />
      <Container>
        <Row>
          <Col md={4}>
            <div className="project-card">
              <a
                href="https://vis-pay-front.vercel.app/"
                target="_blank"
                rel="noreferrer"
              >
                <img
                  src="https://pbrvits.ac.in/images/logo.png"
                  alt=""
                  id="imgs"
                />
              </a>
             
              <div className="project-content">
              <a href="https://vis-pay-front.vercel.app/">https://vis-pay-front.vercel.app/</a>
                <h3>fee collecting website</h3>
                <p>
                  Lorem ipsum dolor sit amet consectetur adipisicing elit.
                  Voluptatibus eius optio repellat, quo illum laudantium
                  repudiandae, veniam inventore minima, laboriosam architecto
                  quis culpa! Neque maxime ab possimus ullam veniam accusantium!
                </p>
              </div>
            </div>
          </Col>
          <Col md={4}>
            <div className="project-card">
              <a
                href="https://vis-pay-front.vercel.app/"
                target="_blank"
                rel="noreferrer"
              >
                <img
                  src="https://pbrvits.ac.in/images/logo.png"
                  alt=""
                  id="imgs"
                />{" "}
              </a>
              <div className="project-content">
              <a href="https://vis-pay-front.vercel.app/">https://vis-pay-front.vercel.app/</a>
                <h3>crimson company website</h3>
                <p>
                  Lorem ipsum dolor sit amet consectetur adipisicing elit.
                  Voluptatibus eius optio repellat, quo illum laudantium
                  repudiandae, veniam inventore minima, laboriosam architecto
                  quis culpa! Neque maxime ab possimus ullam veniam accusantium!
                </p>
              </div>
            </div>
          </Col>
          <Col md={4}>
            <div className="project-card">
              <a
                href="https://vis-pay-front.vercel.app/"
                target="_blank"
                rel="noreferrer"
              >
                <img
                  src="https://pbrvits.ac.in/images/logo.png"
                  alt=""
                  id="imgs"
                />
              </a>
              <div className="project-content">
              <a href="https://vis-pay-front.vercel.app/">https://vis-pay-front.vercel.app/</a>
                <h3>visvoday admission page</h3>
                <p>
                  Lorem ipsum dolor sit amet consectetur adipisicing elit.
                  Voluptatibus eius optio repellat, quo illum laudantium
                  repudiandae, veniam inventore minima, laboriosam architecto
                  quis culpa! Neque maxime ab possimus ullam veniam accusantium!
                </p>
              </div>
            </div>
          </Col>
        </Row>
      </Container>
    </div>
  );
};

export default Projects;
