import React from "react";
import {
    Container,
  Nav,
  Navbar,
  NavbarBrand,
  NavbarOffcanvas,
  NavbarToggle,
  Offcanvas,
  OffcanvasBody,
  OffcanvasHeader,
  OffcanvasTitle,
} from "react-bootstrap";
import { NavLink } from "react-router-dom"; 
import '../styles/Header.css'
const Header = () => {
  return (
    <Navbar expand="md" id="head" >
        <Container>
      <NavbarBrand to="/" className="text-white"  style={{fontSize:30}}><span id="first" style={{fontSize:50}}>P</span >attapu  <span id="first" style={{fontSize:50}}>N</span>aresh</NavbarBrand>
      <NavbarToggle aria-controls="basic-navbar-nav" className="text-white bg-light"/>
      <NavbarOffcanvas placement="end">
        <OffcanvasHeader closeButton>
          <OffcanvasTitle className="logo text-primary" style={{fontSize:30}}><span id="first" style={{fontSize:50}}>P</span>attapu  <span id="first" style={{fontSize:50}}>N</span>aresh</OffcanvasTitle>
        </OffcanvasHeader>
        <OffcanvasBody>
          <Nav className="justify-content-end flex-grow-1 my-3 g-4">
            <NavLink to="/" style={{textDecoration:"none",color:"blue",marginRight:"30px",fontSize:"20px"}} >Home</NavLink><br/>
            <NavLink to="/about"  id="nav-1" style={{textDecoration:"none",color:"blue",marginRight:"30px",fontSize:"20px"}} >About</NavLink><br/>
            <NavLink to="/skills" id="nav-1" style={{textDecoration:"none",color:"blue",marginRight:"30px",fontSize:"20px"}}>
              Skills
            </NavLink>{" "}<br/>
            <NavLink to="/projects" id="nav-1" style={{textDecoration:"none",color:"blue",marginRight:"30px",fontSize:"20px"}} >
              Projects
            </NavLink><br/>
            <NavLink to="/contact"id="nav-1" style={{textDecoration:"none",color:"blue",marginRight:"30px",fontSize:"20px"}} >
              Contact
            </NavLink><br/>
           
          </Nav>
        </OffcanvasBody>
      </NavbarOffcanvas>
      </Container>
    </Navbar>
  );
};

export default Header;
